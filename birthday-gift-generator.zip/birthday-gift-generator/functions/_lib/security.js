const encoder = new TextEncoder();
export function json(data, status = 200, headers = {}) {
 return new Response(JSON.stringify(data), {status,headers:{"content-type":"application/json; charset=utf-8","cache-control":"no-store",...headers}});
}
export function randomBytes(length){const b=new Uint8Array(length);crypto.getRandomValues(b);return b;}
export function toHex(bytes){return Array.from(bytes,b=>b.toString(16).padStart(2,"0")).join("");}
export function fromHex(hex){if(!/^(?:[0-9a-f]{2})+$/i.test(hex||""))return new Uint8Array();return new Uint8Array(hex.match(/.{2}/g).map(x=>parseInt(x,16)));}
export async function sha256Hex(value){return toHex(new Uint8Array(await crypto.subtle.digest("SHA-256",encoder.encode(value))));}
export async function passwordHash(password,saltHex){const key=await crypto.subtle.importKey("raw",encoder.encode(password),"PBKDF2",false,["deriveBits"]);const bits=await crypto.subtle.deriveBits({name:"PBKDF2",salt:fromHex(saltHex),iterations:210000,hash:"SHA-256"},key,256);return toHex(new Uint8Array(bits));}
export function constantTimeEqual(a,b){if(typeof a!=="string"||typeof b!=="string"||a.length!==b.length)return false;let diff=0;for(let i=0;i<a.length;i++)diff|=a.charCodeAt(i)^b.charCodeAt(i);return diff===0;}
export function cookieValue(request,name){const header=request.headers.get("Cookie")||"";for(const part of header.split(";")){const idx=part.indexOf("=");if(idx<0)continue;if(part.slice(0,idx).trim()===name)return part.slice(idx+1).trim();}return "";}
export async function getGift(env,id){if(!/^[a-f0-9]{24}$/.test(id||""))return null;return await env.DB.prepare("SELECT * FROM gifts WHERE id = ?").bind(id).first()||null;}
export async function hasSession(request,env,id){const token=cookieValue(request,"gift_session");if(!token||!/^[A-Za-z0-9_-]{40,60}$/.test(token))return false;const tokenHash=await sha256Hex(token);return !!(await env.DB.prepare("SELECT token_hash FROM sessions WHERE token_hash = ? AND gift_id = ? AND expires_at > ?").bind(tokenHash,id,Date.now()).first());}
export function errorResponse(message,status=400){return json({error:message},status);}
