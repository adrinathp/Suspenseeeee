import { json, errorResponse, randomBytes, toHex, passwordHash } from "../_lib/security.js";
export async function onRequestPost({request,env}){
 if(!env.DB||!env.MEDIA||!env.ADMIN_CREATE_PASSWORD)return errorResponse("The server isn't configured yet. Finish the Cloudflare bindings and secrets first.",503);
 let form;try{form=await request.formData();}catch{return errorResponse("Could not read the uploaded form.");}
 if(String(form.get("createPassword")||"")!==env.ADMIN_CREATE_PASSWORD)return errorResponse("Creator key is incorrect.",403);
 const recipient=String(form.get("recipient")||"").trim().slice(0,80),sender=String(form.get("sender")||"").trim().slice(0,80),age=Number(form.get("age"));
 const signatureLead=String(form.get("signatureLead")||"With love,").trim().slice(0,100),letter=String(form.get("letter")||"").trim().slice(0,12000);
 const closing=String(form.get("closing")||"Happy birthday ♡").trim().slice(0,300),filmLine=String(form.get("filmLine")||"").trim().slice(0,300),giftPassword=String(form.get("giftPassword")||"");
 if(!recipient||!Number.isInteger(age)||age<1||age>120||!letter)return errorResponse("Add the recipient's name, a valid age, and the birthday letter.");
 if(giftPassword.length<8||giftPassword.length>128)return errorResponse("The gift password must be between 8 and 128 characters.");
 const photos=form.getAll("photos").filter(v=>v&&typeof v==="object"&&typeof v.arrayBuffer==="function"&&v.size>0),song=form.get("song");
 if(photos.length>6)return errorResponse("Choose up to 6 photos.");
 for(const photo of photos){if(!String(photo.type||"").startsWith("image/")||photo.size>8*1024*1024)return errorResponse("Each photo must be an image smaller than 8 MB after resizing.");}
 const hasSong=song&&typeof song.arrayBuffer==="function"&&song.size>0;
 if(hasSong&&(song.size>20*1024*1024||!String(song.type||"").startsWith("audio/")))return errorResponse("The song must be an audio file smaller than 20 MB.");
 const id=toHex(randomBytes(12)),salt=toHex(randomBytes(16)),hash=await passwordHash(giftPassword,salt),createdAt=Date.now(),storedKeys=[];
 try{
  for(let i=0;i<photos.length;i++){const key=`gifts/${id}/photo-${i+1}.jpg`;await env.MEDIA.put(key,await photos[i].arrayBuffer(),{httpMetadata:{contentType:"image/jpeg",cacheControl:"private, no-store"}});storedKeys.push(key);}
  let songKey="";
  if(hasSong){const original=String(song.name||"").toLowerCase();const ext=original.endsWith(".ogg")?"ogg":original.endsWith(".wav")?"wav":"mp3";songKey=`gifts/${id}/song.${ext}`;await env.MEDIA.put(songKey,await song.arrayBuffer(),{httpMetadata:{contentType:song.type||"audio/mpeg",cacheControl:"private, no-store"}});storedKeys.push(songKey);}
  await env.DB.prepare("INSERT INTO gifts (id,password_salt,password_hash,recipient,sender,age,signature_lead,letter,closing,film_line,photo_count,song_key,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)")
   .bind(id,salt,hash,recipient,sender,age,signatureLead,letter,closing,filmLine,photos.length,songKey,createdAt).run();
  return json({id,url:`${new URL(request.url).origin}/gift.html?id=${id}`},201);
 }catch(error){await Promise.allSettled(storedKeys.map(key=>env.MEDIA.delete(key)));return errorResponse("Could not save this gift. Check the Cloudflare database/storage setup and try again.",500);}
}