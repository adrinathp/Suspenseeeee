import { errorResponse, getGift, hasSession } from "../../../../../_lib/security.js";
export async function onRequestGet({request,env,params}){
 const id=String(params.id||""),file=String(params.file||""),gift=await getGift(env,id);if(!gift)return errorResponse("This gift link doesn't exist.",404);
 if(!(await hasSession(request,env,id)))return errorResponse("Enter the gift password to view this media.",401);
 if(!/^photo-[1-6]\.jpg$/.test(file)&&file!==(gift.song_key?gift.song_key.split("/").pop():""))return errorResponse("This media file doesn't exist.",404);
 const object=await env.MEDIA.get(`gifts/${id}/${file}`);if(!object)return errorResponse("This media file isn't available.",404);
 const headers=new Headers();object.writeHttpMetadata(headers);headers.set("cache-control","private, no-store");headers.set("x-content-type-options","nosniff");headers.set("content-disposition","inline");
 return new Response(object.body,{headers});
}