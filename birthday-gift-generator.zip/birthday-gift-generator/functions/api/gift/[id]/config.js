import { json, errorResponse, getGift, hasSession } from "../../../_lib/security.js";
export async function onRequestGet({request,env,params}){
 const id=String(params.id||""),gift=await getGift(env,id);if(!gift)return errorResponse("This gift link doesn't exist.",404);
 if(!(await hasSession(request,env,id)))return errorResponse("Enter the gift password to view this gift.",401);
 const photos=[];for(let i=1;i<=gift.photo_count;i++)photos.push(`/api/gift/${id}/media/photo-${i}.jpg`);
 let songUrl="";if(gift.song_key)songUrl=`/api/gift/${id}/media/${encodeURIComponent(gift.song_key.split("/").pop())}`;
 return json({recipient:gift.recipient,sender:gift.sender,age:gift.age,signatureLead:gift.signature_lead,letter:gift.letter,closing:gift.closing,filmLine:gift.film_line,photos,songUrl});
}