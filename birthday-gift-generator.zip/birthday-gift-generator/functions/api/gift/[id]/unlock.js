import { errorResponse, randomBytes, toHex, passwordHash, constantTimeEqual, sha256Hex, getGift } from "../../../_lib/security.js";
export async function onRequestPost({request,env,params}){
 const id=String(params.id||""),gift=await getGift(env,id);if(!gift)return errorResponse("This gift link doesn't exist.",404);
 const ip=request.headers.get("CF-Connecting-IP")||"unknown",ipHash=await sha256Hex(ip),now=Date.now();
 await env.DB.prepare("DELETE FROM unlock_attempts WHERE created_at < ?").bind(now-24*60*60*1000).run();
 const attempts=await env.DB.prepare("SELECT COUNT(*) AS n FROM unlock_attempts WHERE ip_hash = ? AND created_at > ?").bind(ipHash,now-15*60*1000).first();
 if((attempts?.n||0)>=12)return errorResponse("Too many password attempts. Wait 15 minutes before trying again.",429);
 let body;try{body=await request.json();}catch{return errorResponse("Enter the gift password.");}
 await env.DB.prepare("INSERT INTO unlock_attempts (ip_hash,gift_id,created_at) VALUES (?,?,?)").bind(ipHash,id,now).run();
 const candidate=await passwordHash(String(body.password||""),gift.password_salt);
 if(!constantTimeEqual(candidate,gift.password_hash))return errorResponse("That password didn't work. Try again.",401);
 const token=toHex(randomBytes(32)),tokenHash=await sha256Hex(token),expiresAt=now+12*60*60*1000;
 await env.DB.prepare("INSERT INTO sessions (token_hash,gift_id,expires_at) VALUES (?,?,?)").bind(tokenHash,id,expiresAt).run();
 await env.DB.prepare("DELETE FROM unlock_attempts WHERE ip_hash = ? AND gift_id = ?").bind(ipHash,id).run();
 return new Response(JSON.stringify({ok:true}),{status:200,headers:{"content-type":"application/json; charset=utf-8","cache-control":"no-store","set-cookie":`gift_session=${token}; HttpOnly; Secure; SameSite=Lax; Path=/api/gift/${id}; Max-Age=${12*60*60}`}});
}