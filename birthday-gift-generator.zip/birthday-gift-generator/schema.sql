CREATE TABLE IF NOT EXISTS gifts (
 id TEXT PRIMARY KEY, password_salt TEXT NOT NULL, password_hash TEXT NOT NULL,
 recipient TEXT NOT NULL, sender TEXT NOT NULL DEFAULT '', age INTEGER NOT NULL,
 signature_lead TEXT NOT NULL DEFAULT 'With love,', letter TEXT NOT NULL,
 closing TEXT NOT NULL DEFAULT 'Happy birthday ♡', film_line TEXT NOT NULL DEFAULT '',
 photo_count INTEGER NOT NULL DEFAULT 0, song_key TEXT NOT NULL DEFAULT '', created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions (
 token_hash TEXT PRIMARY KEY, gift_id TEXT NOT NULL, expires_at INTEGER NOT NULL,
 FOREIGN KEY (gift_id) REFERENCES gifts(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS sessions_gift_expiry ON sessions(gift_id,expires_at);
CREATE TABLE IF NOT EXISTS unlock_attempts (
 id INTEGER PRIMARY KEY AUTOINCREMENT, ip_hash TEXT NOT NULL, gift_id TEXT NOT NULL, created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS unlock_attempts_ip_time ON unlock_attempts(ip_hash,created_at);
