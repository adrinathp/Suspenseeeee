BIRTHDAY GIFT GENERATOR — Cloudflare Pages + private R2 + D1

This project keeps the existing birthday experience as viewer.html, with its layout, colors, scenes, and animations. It adds a separate generator page, password gate, and private media delivery.

PRIVACY
- Uploaded photos and music are stored in a private R2 bucket. Do not enable public bucket access or create a public R2 custom domain.
- Gift passwords are stored as PBKDF2-SHA256 hashes with random salts, not plain text.
- The generator requires the ADMIN_CREATE_PASSWORD secret. Set a strong unique value in Cloudflare and never share it with the recipient.
- A viewer can still take screenshots or record audio after opening a gift.
- The original embedded personal photo and personal letter defaults are not included in public files. Paste the letter into the generator when creating a gift.
- This package contains no uploaded gift media.

FILES
- index.html: generator page
- gift.html: password entry page
- viewer.html: existing birthday experience with dynamic private gift data
- functions/: Pages Functions for creation, password verification, and private media
- schema.sql: D1 schema

CLOUDFLARE SETUP
1. Create a Cloudflare account and open Workers & Pages.
2. Create a D1 database named birthday-gifts.
3. In the D1 Console, run the full contents of schema.sql.
4. Create an R2 bucket named birthday-gift-media. Keep public access disabled.
5. Deploy this folder as a Cloudflare Pages project. Recommended: push the files to a new private GitHub repository, then connect that repo in Cloudflare Pages. Use the repository root as build output directory and no build command.
6. In Pages > Settings > Functions > Bindings, add a D1 database binding named DB and select birthday-gifts.
7. Add an R2 bucket binding named MEDIA and select birthday-gift-media.
8. In Pages > Settings > Variables and Secrets, add an encrypted secret named ADMIN_CREATE_PASSWORD. Use a strong password only you know. Redeploy after adding bindings/secrets.
9. Visit https://YOUR-PROJECT.pages.dev/. Enter the creator key, details, letter, photos, optional song, and a separate gift password.
10. Click Generate gift link. Send the link to her and send the gift password separately.
11. Test with a non-sensitive sample gift first: wrong password must fail, correct password should show the birthday design.

SECURITY / OPERATIONS
- Never make the R2 bucket public.
- The unlock endpoint limits failed attempts per IP over a 15-minute window using D1.
- Viewer sessions expire after 12 hours. After expiry, open the gift link and enter the password again.
- Gifts/media are not automatically deleted. Delete the gift row and its R2 objects when no longer needed; deletion tooling can be added later.
- Up to 6 photos. The browser resizes them before upload. Processed photos must be under 8 MB each; song must be under 20 MB.
- The function files must be in a `functions/` directory at the repository root. Deploy as Cloudflare Pages, not a static-only host.
- Use an audio file you have permission to publish. Browsers usually require a tap before music can start.

DESIGN
The viewer was derived from the supplied birthday-site-ready version. Existing design CSS and scene/animation code are retained. Personal defaults and the embedded personal photo were removed from public source files so each gift's text/media is supplied by the private record after password verification.
